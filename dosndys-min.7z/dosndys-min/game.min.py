AD='Invalid choice'
AC='./maps'
AB='\x1b[38;2;255;255;0m■\x1b[0m'
AA='\x1b[38;2;0;255;0m■\x1b[0m'
A9='\x1b[38;2;0;0;255m■\x1b[0m'
A8=KeyError
x='P'
w='E'
v=enumerate
p='#'
o=set
g=ValueError
X='\n'
W='global.json does not conform to settings schema'
S='U'
R='O'
Q=len
P=' '
O=int
E=True
C=print
A=False
import shutil,random as h,time,os as Y,json as y,math as z
try:import keyboard as I
except ImportError:raise ModuleNotFoundError("keyboard module not installed, please run 'pip install keyboard'")
from collections import Counter as q
from typing import Any
with open('./global.json','r')as AE:
	try:i=y.load(AE)
	except(FileNotFoundError,y.JSONDecodeError):raise g('global.json either does not exist or does not conform to valid JSON')
try:j=i['coins'];k=i['skillcheck'];AF=i['onmapload'];Z=i['moveset']
except A8:raise g(W)
def a():Y.system('cls')if Y.name=='nt'else Y.system('clear');C()
def r(types,*A):return types==[type(A)for A in A]
try:l=j['coins_until_end'];A0=j['MINIMUM_LEVEL_FOR_COIN_REQ_INCREASE'];AG=j['INCREASE_ONLY_WHEN_LEVEL_MODULO_IS_ZERO'];A1=j['AMOUNT_TO_INCREASE_BY'];b=k['SKILL_CHECK_MARKER_SIZE'];s=k['SKILL_CHECK_SIZE'];t=k['SKILL_CHECK_CENTER_RANGE'];A2=k['SKILL_CHECK_SPEED'];D=[Z['UP'],Z['LEFT'],Z['DOWN'],Z['RIGHT'],Z['SKILLCHECK']];A3=AF['USE_RANDOM_SPAWN_POINT']
except A8:raise g(W)
assert r([O,O,O],l,A0,A1),W
assert r([O,O,O,O],b,s,t,A2),W
assert o(type(A)for A in D)==o([str]),W
assert r([bool],A3),W
def AH(map):B='Invalid map';global A4;C=map.splitlines();E=[Q(A)for A in C];A=list(o(E));assert sorted(o(map))==[X,P,p,w,R,S]and q(map).get(R)==1 and q(map).get(S)==1 and q(map).get(w)==3,B;assert'EEE'in map,B;assert Q(A)==2 and A[0]==0,B;assert Q(D)==5,'Amount of keys in moveset must be exactly 5';A4=A[1]
def AI():
	L='Game over! You ran out of coins.';global J,B;F=h.randint(0,s);G=0;C();C(J[:-3].replace(p,A9).replace(x,AA).replace(R,AB).replace(S,P),flush=E);C(P*F+'\x1b[38;2;255;255;0m▄\x1b[0m'*b)
	for N in range(s+b):
		C('\x1b[38;2;255;255;255m▀\x1b[0m',end='',flush=E);G+=1;A=-(F-G)
		if A<=b and A>0:
			K=b/2;M=A>K-t and A<K+t+1
			if I.is_pressed(D[4]):a();return 1+M
		elif I.is_pressed(D[4]):
			if H==0:a();C(L);exit()
			else:C();C()
			return-1
		time.sleep(1/A2)
	if H==0:a();C(L);exit()
	a();return-1
def AJ():
	global B,H,c,T;A=AI();H+=A;B=B.replace(R,P);C=[A for(A,B)in v(B)if B==P]
	if C:D=h.choice(C);B=B[:D]+R+B[D+1:]
	if A==-1:c=E
	T=E
def AK():
	global B;B=B.replace(S,P);A=[A for(A,B)in v(B)if B==P]
	if A:C=h.choice(A);B=B[:C]+S+B[C+1:]
def m(state,player_char):
	O=player_char;I=state;global H,B,U,K,L,M,N,F,G,J,T,d,e,V;C=list(I[U:]);D=C.index(S)+F-G*(U+A4+1)
	if D<0 or D>Q(C):F=0;G=0;K=A;M=A;L=A;N=A;d=E;return m(I,O)
	elif C[D]==p:
		if K:F+=1
		elif L:G+=1
		elif M:G-=1
		elif N:F-=1
		V=E;return m(I,O)
	elif C[D]==R:AJ()
	elif C[D]==w:
		if H>=l:G=0;F=0;e=1
		else:
			if K:F+=1
			elif L:G+=1
			elif M:G-=1
			elif N:F-=1
			V=E;return m(I,O)
	C[D]=O;return I[:U]+''.join(C)
def AL():
	global U,K,L,M,N,F,G,J,d,c,T,n,B,e,H,f,V;e=0;AH(B);Y=shutil.get_terminal_size();Z=B.splitlines();g=lambda line:round(Y.columns/2)-round(Q(line)/2);a=z.floor(Y.lines/2)-z.floor(Q(Z)/2);J=X*a
	for b in Z:U=g(b);J+=P*U+b+X
	J+=X*a;J=m(J,x)
	if not V:
		if not T:C()
		C(J[:-2].replace(p,A9).replace(x,AA).replace(R,AB).replace(S,P),end='',flush=E);O=f"Coins: [38;2;255;255;0m{H}[0m";O+=f"/{l} | Level: {f}"
		if d and not n:O+=' | \x1b[38;2;255;0;0mCheating detected, you have been placed back in the map!\x1b[0m'
		elif n:O+=f" | X Position: {F} | Y Position: {G} | Terminal: {Y}"
		if c:O+=f" | [38;2;255;0;0mThe machine took away your coin because you messed it up![0m"
		C(O)
	V=A;T=A;c=A;d=A
	while 1:
		h=I.read_event()
		if h.event_type==I.KEY_DOWN:
			W=I.is_pressed
			if E in[W(D[0]),W(D[1]),W(D[2]),W(D[3])]:break
	if I.is_pressed(D[1]):K=E;M=A;L=A;N=A;F-=1
	elif I.is_pressed(D[3]):K=A;M=A;L=A;N=E;F+=1
	elif I.is_pressed(D[0]):K=A;M=E;L=A;N=A;G+=1
	elif I.is_pressed(D[2]):K=A;M=A;L=E;N=A;G-=1
	return e
C("\nDDDDD    OOOOO    SSSSS  NN    N  DDDDD   YY   YY  ''   SSSSS\nD   DD  OO   OO  S       N N   N  D   DD   YY YY   ''  S     \nD    D  O     O   SSSS   N  N  N  D    D    YYY         SSSS \nD   DD  OO   OO       S  N   N N  D   DD     Y              S\nDDDDD    OOOOO   SSSSS   N    NN  DDDDD      Y         SSSSS\nW     W     W   OOOOO   RRRRR   L       DDDDD\nW    W W    W  OO   OO  R    R  L       D   DD\nW   W   W   W  O     O  RRRRR   L       D    D\n W W     W W   OO   OO  R   R   L       D   DD\n  W       W     OOOOO   R    R  LLLLLL  DDDDD\n")
C('\nMade by UnbuiltAlmond8\nFor advanced users, see ./docs.py for information on customizing\nthe game.\n')
C(f"""This is a simple game where you try to collect random coins
to get higher scores. To get coins, you need to perform a
skill check by pressing Space when the bar is within the
marker. If unsuccessful, a coin is deducted.

Once you get enough coins, you can enter the elevator to go to
the next level.

The game ends when your coins become in debt.

Move using the {", ".join(D[:-2]).upper()} and {D[-2].upper()} keys.

For best results, you may need to reduce your terminal
zoom size and use a TTY that has ANSI color support.""")
A5=input('Ready? (Ctrl+C or Ctrl+D to quit) ').lower()
assert not A5.startswith('n'),'Game exited.'
n=A5=='debug'
a()
def u(chosen_index=None):
	A=chosen_index;global B,H;C=Y.listdir(AC)
	if A is None:A=h.randint(1,Q(C))
	with open(f"./maps/map{A}.txt",'r')as D:
		E=D.read();B=X+E+X
		if A3:AK()
		H=0
u()
H=0
K=A
M=A
L=A
N=A
F=0
G=0
d=A
V=A
c=A
T=A
e=0
f=0
if n:
	C('Debug mode enabled, please choose a map.\n');A6=Y.listdir(AC)
	for(AM,AN)in v(A6):C(f"{AM+1}) {AN}")
	C();A7=input('Choose an option: ')
	try:assert 1<=O(A7)<=Q(A6),AD
	except g:raise g(AD)
	u(chosen_index=O(A7))
while 1:
	AO=AL()
	if AO==1:
		f+=1
		if f>=A0 and f%AG==0:l+=A1
		u()